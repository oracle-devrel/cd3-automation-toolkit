Copyright (c) 2017-2018, Oracle and/or its affiliates. All rights reserved.

Oracle Cloud Infrastructure Object Storage Classic - File Transfer Manager CLI
---------------------------------------------------------

The File Transfer Manager (FTM) CLI is a Java-based command line tool (CLI) that simplifies uploading, downloading, and managing your data in the Oracle Cloud Infrastructure Object Storage Classic.

Key features:
    -	Upload and download individual files or entire directories
    -	Support for listing and deleting containers and objects
    -	Restore objects from archive storage
    -	Display, set, and update metadata on account, containers, and objects
    -   Support for both Client Side Encryption and Server Side Encryption
    -	Optimized uploads and downloads through automatic segmentation and parallelization to maximize network efficiency and reduce overall transfer time
    -	Automatic retry on failures
    -	Automatic checksum verification on upload and download
    -	Resume of upload transfer for large files
    -   copy an object within a container to another container of standard or archive storage type.
    -   Set and display container replication policies

Requirements: JRE 7 or later

Command Help:
java -jar ftmcli.jar --help